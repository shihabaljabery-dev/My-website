// WowSlider initialization
document.addEventListener("DOMContentLoaded", () => {
  console.log("WowSlider script initialized");
});
