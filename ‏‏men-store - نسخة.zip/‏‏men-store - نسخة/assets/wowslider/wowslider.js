// Basic WowSlider JS
console.log("WowSlider core loaded");
