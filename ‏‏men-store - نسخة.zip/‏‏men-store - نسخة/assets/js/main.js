// يتطلب jQuery + Bootstrap + Toastr + jQuery Validate
$(function () {
  // تفعيل الرابط النشط
  const path = location.pathname.split('/').pop() || 'index.html';
  $('nav a').each(function () {
    if ($(this).attr('href') === path) { $(this).addClass('active'); }
  });

  // إعدادات Toastr
  toastr.options = {
    timeOut: 1200,
    positionClass: 'toast-top-right',
    rtl: true,
    progressBar: true
  };

  /* =========================
     دوال السلة (localStorage)
     ========================= */
  function getCart() {
    try { return JSON.parse(localStorage.getItem('cart') || '[]'); }
    catch { return []; }
  }
  function setCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateBadge(cart);
  }
  function updateBadge(cart = getCart()) {
    const count = cart.reduce((sum, it) => sum + (it.qty || 1), 0);
    const $badge = $('#cartCount');
    if ($badge.length) $badge.text(count > 0 ? count : '');
  }
  updateBadge();

  function addToCart({ name, price, image }) {
    let cart = getCart();
    const idx = cart.findIndex(it => it.name === name && it.price === price);
    if (idx >= 0) {
      cart[idx].qty = (cart[idx].qty || 1) + 1;
    } else {
      cart.push({ name, price, qty: 1, image: image || '' });
    }
    setCart(cart);
  }

  function changeQty(index, delta) {
    let cart = getCart();
    if (!cart[index]) return;
    cart[index].qty = Math.max(1, (cart[index].qty || 1) + delta);
    setCart(cart);
    renderCartTable(); // إن وُجدت صفحة السلة
  }

  function removeItem(index) {
    let cart = getCart();
    cart.splice(index, 1);
    setCart(cart);
    renderCartTable();
  }

  function clearCart() {
    setCart([]);
    renderCartTable();
  }

  /* =========================
     أحداث الأزرار العامة
     ========================= */
  // زر "أضف للسلة" في بطاقات المنتجات
  $(document).on('click', '.add-to-cart', function (e) {
    e.preventDefault();
    const $btn = $(this);
    const name = $btn.data('name') || 'منتج';
    const price = parseFloat($btn.data('price')) || 0;
    const image = $btn.data('img') || '';
    addToCart({ name, price, image });
    toastr.success(`${name} أُضيف إلى السلة`);
  });

  // مودال "نظرة سريعة"
  $(document).on('click', '[data-modal="quick-view"]', function (e) {
    e.preventDefault();
    $('#ajaxModal .modal-body').load('assets/fragments/quick-view.html', function () {
      $('#ajaxModal').modal('show');
    });
  });


  /* =========================
     نماذج الدخول/التسجيل
     ========================= */
  if ($('#signupForm').length) {
    $('#signupForm').validate({
      rules: {
        fullname: { required: true, minlength: 3 },
        email: { required: true, email: true },
        password: { required: true, minlength: 6 },
        confirm: { required: true, equalTo: '#password' }
      },
      messages: {
        fullname: "اكتب الاسم",
        email: "اكتب بريدًا صحيحًا",
        password: "6 أحرف على الأقل",
        confirm: "غير مطابق"
      },
      submitHandler: function (form) {
        toastr.success('تم إنشاء الحساب');
        form.reset();
        return false;
      }
    });
  }

  if ($('#loginForm').length) {
    $('#loginForm').validate({
      rules: { email: { required: true, email: true }, password: { required: true, minlength: 6 } },
      messages: { email: "اكتب بريدًا صحيحًا", password: "مطلوبة" },
      submitHandler: function (form) {
        toastr.success('تم تسجيل الدخول');
        form.reset();
        return false;
      }
    });
  }

  // تأثير الهيدر عند التمرير
  $(window).on('scroll', function () {
    $('header').toggleClass('scrolled', window.scrollY > 10);
  });

  /* =========================
     صفحة السلة (cart.html)
     ========================= */
  function formatUSD(n) { return `$${(n || 0).toFixed(2)}`; }

  function renderCartTable() {
    const $table = $('#cartTable');
    if (!$table.length) return; // نحن لسنا في صفحة السلة

    const cart = getCart();
    const $tbody = $table.find('tbody');
    let total = 0;

    if (cart.length === 0) {
      $tbody.html(`<tr><td colspan="5" class="text-center py-5">السلة فارغة</td></tr>`);
      $('#cartTotal').text(formatUSD(0));
      $('#checkoutBtn').prop('disabled', true);
      $('#clearCartBtn').prop('disabled', true);
      return;
    }

    const rows = cart.map((item, i) => {
      const line = (item.price || 0) * (item.qty || 1);
      total += line;
      return `
        <tr>
          <td class="align-middle">
            <div class="d-flex align-items-center gap-2">
              ${item.image ? `<img src="${item.image}" alt="" width="48" height="48" class="rounded">` : ''}
              <strong>${item.name}</strong>
            </div>
          </td>
          <td class="align-middle">
            <div class="btn-group" role="group" aria-label="qty">
              <button class="btn btn-sm btn-outline-secondary qty-dec" data-index="${i}">-</button>
              <span class="px-3">${item.qty || 1}</span>
              <button class="btn btn-sm btn-outline-secondary qty-inc" data-index="${i}">+</button>
            </div>
          </td>
          <td class="align-middle">${formatUSD(item.price)}<div class="text-muted small">الإجمالي: ${formatUSD(line)}</div></td>
          <td class="align-middle text-end">
            <button class="btn btn-sm btn-danger remove" data-index="${i}">حذف</button>
          </td>
        </tr>`;
    }).join('');

    $tbody.html(rows);
    $('#cartTotal').text(formatUSD(total));
    $('#checkoutBtn').prop('disabled', false);
    $('#clearCartBtn').prop('disabled', false);
  }

  // أربط أحداث الكمية/الحذف
  $(document).on('click', '.qty-inc', function () {
    changeQty($(this).data('index'), +1);
  });
  $(document).on('click', '.qty-dec', function () {
    changeQty($(this).data('index'), -1);
  });
  $(document).on('click', '.remove', function () {
    removeItem($(this).data('index'));
    toastr.info('تم حذف العنصر من السلة');
  });
  $(document).on('click', '#clearCartBtn', function () {
    if (confirm('هل تريد مسح السلة بالكامل؟')) {
      clearCart();
      toastr.info('تم مسح السلة');
    }
  });
  $(document).on('click', '#checkoutBtn', function () {
    const cart = getCart();
    if (!cart.length) return;
    toastr.success('تم إرسال طلب الشراء (نموذج تجريبي)');
    // هنا لاحقًا: إرسال الطلب للباك-إند
  });

  // نفّذ ريندر لو نحن في صفحة السلة
  renderCartTable();
});